package com.example.EmployeeManagenmentSystem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmployeeManagenmentSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
