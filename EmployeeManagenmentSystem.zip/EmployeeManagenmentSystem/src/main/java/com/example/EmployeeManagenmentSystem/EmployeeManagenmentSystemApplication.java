package com.example.EmployeeManagenmentSystem;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EmployeeManagenmentSystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(EmployeeManagenmentSystemApplication.class, args);
	}

}
